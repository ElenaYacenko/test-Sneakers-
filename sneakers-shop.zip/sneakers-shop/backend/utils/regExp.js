const regExpUrl = /https?:\/\/[\w-]+\.[-._~:/?#[\]@!$&'()*+,;=\w]+/;

module.exports = regExpUrl;
